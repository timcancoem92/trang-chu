﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetPassBrowser
{
    public class Account
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public string URL { get; set; }

        public string Application { get; set; }
    }

}
